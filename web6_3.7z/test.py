import sqlite3


class Database(object):
    _instance = None

    @classmethod
    def instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        else:
            pass
        return cls._instance

    def __init__(self):
        db_path = 'demo.sqlite'
        self.connection = sqlite3.connect(db_path)

    @classmethod
    def __call__(self):
        raise TypeError('use instance()')

    def __enter__(self):
        print('enter')
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.connection.close()
        print('exit')


def main():
    d1 = Database.instance()
    d2 = Database.instance()
    print(id(d1), id(d2), d1, d2, d1 is d2)


if __name__ == '__main__':
    with Database.instance():
        d1 = Database.instance()
        d2 = Database.instance()
        print(id(d1), id(d2), d1, d2, d1 is d2)
        main()
