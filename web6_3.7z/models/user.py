from models import Model
from models.user_role import UserRole


class User(Model):
    """
    User 是一个保存用户数据的 model
    现在只有两个属性 username 和 password
    """

    def __init__(self, form):
        super().__init__(form)
        self.username = form.get('username', '')
        self.password = form.get('password', '')
        self.role = form.get('role', UserRole.normal)

    @staticmethod
    def guest():

        form = dict(
            role=UserRole.guest,
            username='【游客】',
        )
        u = User(form)
        return u

    def is_guest(self):
        return self.role == UserRole.guest


    @classmethod
    def login(cls, form):
        u = User.find_by(username=form['username'], password=form['password'])
        if u is not None:
            result = '登录成功'
            return u, result
        else:
            result = '用户名或者密码错误'
            return User.guest(), result

    @classmethod
    def register(cls, form):
        valid = len(form['username']) > 2 and len(form['password']) > 2
        if valid:
            u = User.new(form)
            result = '注册成功<br> <pre>{}</pre>'.format(User.all())
            return u, result
        else:
            result = '用户名或者密码长度必须大于2'
            return User.guest(), result
