from models.todo import Todo
from routes import (
    redirect,
    GuaTemplate,
    current_user,
    html_response,
    login_required,
    formatted_header
)
from utils import log


def all(request):
    """
    todo 首页的路由函数
    """
    u = current_user(request)
    todos = Todo.find_all(user_id=u.id)
    # 替换模板文件中的标记字符串
    body = GuaTemplate.render('todo_index.html', todos=todos)
    # bad_template.render('todo_index.html', todos=todos)
    return html_response(body)


def add(request):
    """
    用于增加新 todo 的路由函数
    """
    u = current_user(request)
    form = request.form()
    log('todo_add_user_id <{}>'.format(u))
    Todo.add(form, u.id)
    # 浏览器发送数据过来被处理后, 重定向到首页
    # 浏览器在请求新首页的时候, 就能看到新增的数据了
    return redirect('/todo/all')


def delete(request):
    todo_id = int(request.query['id'])
    Todo.delete(todo_id)
    return redirect('/todo/all')


def edit(request):
    todo_id = int(request.query['id'])
    t = Todo.find_by(id=todo_id)
    body = GuaTemplate.render('todo_edit.html', todo=t)
    return html_response(body)


# @login_required
def update(request):
    """
    用于增加新 todo 的路由函数
    """
    form = request.form()
    Todo.update(form)
    # 浏览器发送数据过来被处理后, 重定向到首页
    # 浏览器在请求新首页的时候, 就能看到新增的数据了
    return redirect('/todo/all')


def same_user_required(route_function):

    def f(request):
        log('same_user_required')
        u = current_user(request)

        if request.method == 'GET':
            todo_id = int(request.query['id'])
        elif request.method == 'POST':
            todo_id = int(request.form()['id'])
        else:
            raise ValueError('只能接受 GET 或者 POST 请求')

        t = Todo.find_by(id=todo_id)
        if t.user_id == u.id:
            log('同一个用户', route_function)
            return route_function(request)
        else:
            log('不是同一个用户')
            return redirect('/todo/all')

    return f

# RESTFul
# POST /todo
# DELETE /todo
# update /todo
# GET /todo
# GET /todo/1
# GET /todo/?id=1
# UPDATE /todo/1
# /question/1/answer/2/comment/3
# /1/2/3

def route_dict():
    """
    路由字典
    key 是路由(路由就是 path)
    value 是路由处理函数(就是响应)
    """
    d = {
        '/todo/add': login_required(add),
        '/todo/delete': login_required(delete),
        '/todo/edit': login_required(same_user_required(edit)),
        '/todo/update': login_required(same_user_required(update)),
        # '/todo/edit': login_required(edit),
        # '/todo/update': login_required(update),
        '/todo/all': login_required(all),
    }
    return d
